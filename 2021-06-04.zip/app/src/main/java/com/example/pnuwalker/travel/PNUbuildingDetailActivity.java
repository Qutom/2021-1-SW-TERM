package com.example.pnuwalker.travel;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.pnuwalker.R;

public class PNUbuildingDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.travel_building_detail);
    }
}
